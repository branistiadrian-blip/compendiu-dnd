package com.emarbiland.dmtoolkit;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
